<!DOCTYPE html>
	<head>
		<meta charset = "utf-8">
		<lang = "eng">
		<link rel = "stylesheet" href = "../css/styles.css">
	</head>
	<table cellspacing = "0" id = "nagytabla">
		<tr>
			<td id = "keptar">
	<div>
	<image src = "../images/oneletrajzkep.png">
	</div>
			</td>
		</tr>
		<tr>
			<td>
		<h2>
		Work experience
		</h2>
		<h4>
		Delivery driver
		</h4>
		<div class = "szurke">
		Self-employed
		2023-09 - current position
		</div>
		<p>
		Mecses webpage development alongside
		<a href = "https://mecses.vaciegyhazmegye.hu/php/index.php" target = "_blank">(mecses.vaciegyhazmegye.hu)</a>
		</p>
		<h4>
		IT Technician
		</h4>
		<div class = "szurke">
		Perfect-Phone kft.
		2019-08 - 2023-01
		</div>
		<p>
		Telefon Exchange programming, fiber optic cable splicing, building structured networks, cable wiring, assembly and installation <br>
		Hungarian fiber optic border security network, Paks Nuclear Plant, Police stations,
		Educational region, Banks surveillance, IT and phone network corrective maintenence
		</p>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>
			</td>
		</tr>
		
		<tr>
			<td>
		<h2>
		Education
		</h2>
		<h4>
		Shop assistant
		</h4>
		<div class = "szurke">
		2023-02 - 2023-08
		</div>
		<p>
		</p>
		<h4>
		Software developer
		</h4>
		<div class = "szurke">
		Szeged SZC Vasvári Pál Economy and Informatical Technical Institute
		2017-09 - 2019-05
		</div>
		<p>
		C++, C#, html, php, css, OOP, web development, data base management, linq
		</p>
		<h4>		
MIK
		</h4>
		<div class = "szurke">
University of Pecs Engineering It and architecture
2016-02 - 2017-07
		</div>
		<h4>	
Informatical high school graduation
		</h4>	
		<div class = "szurke">
Szekszárd I. Béla Gimnázium
2012-09 - 2016-07
		</div>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>
			</td>
		</tr>
		
		<tr>
			<td>
		<h2>
Languages
		</h2>
		
		<h4>
English
		</h4>
		<div class = "szurke">
Upper intermidiate
		</div>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>	
			</td>
		</tr>	
		<tr>
			<td>
		<h2>
Drivers license
		</h2>
		<h4>
Category B
		</h4>
		<tr>
			<td class = "vonal">	
		<hr>
			</td>
		</tr>	
		
		<tr>
			<td class = "hobbiresz">
		<h2>
Hobbies
		</h2>
		<div id = "hobbikep">
			<image src = "../images/hobbiKepAngol.png">
		</div>
			</td>
		</tr>	
	</table>	
</html>