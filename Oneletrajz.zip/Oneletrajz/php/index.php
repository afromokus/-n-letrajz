<!DOCTYPE html>
	<head>
		<meta charset = "utf-8">
		<lang = "hu">
		<link rel = "stylesheet" href = "../css/styles.css">
	</head>
	<table cellspacing = "0" id = "nagytabla">
		<tr>
			<td id = "keptar">
	<div>
	<image src = "../images/oneletrajzkep.png">
	</div>
			</td>
		</tr>
		<tr>
			<td>
		<h2>
		Szakmai tapasztalat
		</h2>
		<h4>
		Élelmiszer kiszállítás
		</h4>
		<div class = "szurke">
		Egyéni Vállalkozóként
		2023-09 - jelenleg is
		</div>
		<p>
		Mellette Mécses börtönpasztoráció weboldalának fejlesztése
		<a href = "https://mecses.vaciegyhazmegye.hu/php/index.php" target = "_blank">(mecses.vaciegyhazmegye.hu)</a>
		</p>
		<h4>
		Informatikai műszerész
		</h4>
		<div class = "szurke">
		Perfect-Phone kft.
		2019-08 - 2023-01
		</div>
		<p>
		Telefonközpontok programozása, optikai szálhegesztés, struktúrált
		hálózatépítés, kábelszerelés <br>
		Országos Optikai határvédelmi hálózat, Paksi Atomerőmű, Rendőrség,
		Tankerület, Bankok kamerájának, informatikai és telefonhálózatának
		karbantartása, javítása
		</p>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>
			</td>
		</tr>
		
		<tr>
			<td>
		<h2>
		Tanulmányok
		</h2>
		<h4>
		Bolti eladó
		</h4>
		<div class = "szurke">
		2023-02 - 2023-08
		</div>
		<p>
		</p>
		<h4>
		Szoftverfejlesztő
		</h4>
		<div class = "szurke">
		Szegedi SZC Vasvári Pál Gazdasági és Informatikai Technikum
		2017-09 - 2019-05
		</div>
		<p>
		C++, C#, html, php, css, OOP, hálózatépítés, adatbáziskezelés, linq
		</p>
		<h4>		
MIK
		</h4>
		<div class = "szurke">
Pécsi Tudományegyetem Műszaki és Informatikai Kar
2016-02 - 2017-07
		</div>
		<h4>	
Informatika Érettségi
		</h4>	
		<div class = "szurke">
Szekszárdi I. Béla Gimnázium
2012-09 - 2016-07
		</div>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>
			</td>
		</tr>
		
		<tr>
			<td>
		<h2>
Nyelvismeret
		</h2>
		
		<h4>
Angol
		</h4>
		<div class = "szurke">
Középfok/kommunikációképes szint
		</div>
			</td>
		</tr>
		<tr>
			<td class = "vonal">
		<hr>	
			</td>
		</tr>	
		<tr>
			<td>
		<h2>
Jogosítvány
		</h2>
		<h4>
B
		</h4>
		<div class = "szurke">
Személygépkocsi
		</div>	
			</td>
		</tr>	
		<tr>
			<td class = "vonal">	
		<hr>
			</td>
		</tr>	
		
		<tr>
			<td class = "hobbiresz">
		<h2>
Hobbik
		</h2>
		<div id = "hobbikep">
			<image src = "../images/hobbiKepEredeti.png">
		</div>
			</td>
		</tr>	
	</table>	
</html>